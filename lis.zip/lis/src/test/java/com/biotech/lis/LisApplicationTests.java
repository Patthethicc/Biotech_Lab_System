package com.biotech.lis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LisApplicationTests {

	@Test
	void contextLoads() {
	}

}
